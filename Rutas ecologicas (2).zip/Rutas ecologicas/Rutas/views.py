from django.shortcuts import render, redirect
from django.conf import settings
from django.core.mail import send_mail
import datetime
# Create your views here.

from .models import Proyecto

def index(request):
    return render(request,'index.html',)

def log_in(request):
    return render(request,'Log_In.html')

def sign_up(request):
    return render(request,'Formulario.html')

def Pago(request):
    return render(request, 'Pago.html')

def banco_proyectos(request):
    return render(request,'inner-page.html' )
    
def BucaPinta(request):
    return render(request,'Pinta.html')

def Guajira(request):
    return render(request,'portfolio-details.html')

def SantanderSolar(request):
    return render(request,'Santander.html')

def interAdmin(request):
    return render(request,'InterAdmin.html')

def interUser(request):
    return render(request,'interUser.html')

def Post(request):
    return render(request,'post.html')

def wdw_snippet(request):
    return render(request,'wdw-snippet.html')

def enviar (request):
    return render(request,'enviar.html')
    
def enviarcorreo(request):
    if request.method == "POST":
        subject =request.POST['asunto']
        message= "Nombre:  "+ request.POST['nombre']+ "\r\n\n  informacion sobre el proyecto: \r\n "+request.POST['mensaje']
        email_from=settings.EMAIL_HOST_USER
        recipent_list=["rutasecologicasuis@gmail.com"]
        send_mail(subject,message, email_from, recipent_list)

        return redirect('enviar.html')
    return render(request, "enviar.html")